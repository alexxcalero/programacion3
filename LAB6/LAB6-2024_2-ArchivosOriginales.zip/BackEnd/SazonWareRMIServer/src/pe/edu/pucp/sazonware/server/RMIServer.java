package pe.edu.pucp.sazonware.server;
public class RMIServer {
    public static void main(String[] args){
        
    }
}
