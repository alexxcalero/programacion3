package pe.edu.pucp.sazonware.model;
import java.io.Serializable;
public enum Categoria implements Serializable{
    ENTRADA, FONDO, POSTRE
}
