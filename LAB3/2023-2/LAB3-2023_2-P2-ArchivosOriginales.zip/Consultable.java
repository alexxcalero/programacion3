interface Consultable{
	String consultarDatos();
}