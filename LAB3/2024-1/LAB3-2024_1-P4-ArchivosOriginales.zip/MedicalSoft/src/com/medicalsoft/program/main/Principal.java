package com.medicalsoft.program.main;

/**
 * Coloque su codigo y nombre completo
 * Codigo PUCP:
 * Nombre Completo:
 */
public class Principal {
    public static void main(String[] args){
        /*Complete para que sea posible el registro en la base de datos 
        de una sala especializada cuyos datos se lean desde consola*/
    }
}
