package com.medicalsoft.infraestructura.dao;

public interface SalaEspecializadaDAO {
    //int insertar(SalaEspecializada salaEspecializada);
}
