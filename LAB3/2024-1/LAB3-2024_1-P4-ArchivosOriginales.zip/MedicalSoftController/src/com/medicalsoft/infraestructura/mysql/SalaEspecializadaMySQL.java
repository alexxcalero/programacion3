package com.medicalsoft.infraestructura.mysql;
import com.medicalsoft.infraestructura.dao.SalaEspecializadaDAO;
import java.sql.Connection;

public class SalaEspecializadaMySQL implements SalaEspecializadaDAO{

    private Connection con;
    private String sql;
    
    /*
    @Override
    public int insertar(SalaEspecializada salaEspecializada) {
        //Implemente el método de registro de una sala especializada
    }
    */
}
