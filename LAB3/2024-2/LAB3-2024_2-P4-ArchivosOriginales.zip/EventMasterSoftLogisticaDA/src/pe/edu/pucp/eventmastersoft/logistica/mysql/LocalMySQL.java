package pe.edu.pucp.eventmastersoft.logistica.mysql;
import pe.edu.pucp.eventmastersoft.logistica.dao.LocalDAO;
public class LocalMySQL implements LocalDAO{
    
}
