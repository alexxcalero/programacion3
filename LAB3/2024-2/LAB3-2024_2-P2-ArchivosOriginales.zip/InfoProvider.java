interface InfoProvider{
	String devolverDatos();
}