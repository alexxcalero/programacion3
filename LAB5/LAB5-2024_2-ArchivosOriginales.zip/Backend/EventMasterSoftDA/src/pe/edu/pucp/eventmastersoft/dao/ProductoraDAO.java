package pe.edu.pucp.eventmastersoft.dao;

import java.util.ArrayList;
import pe.edu.pucp.eventmastersoft.model.Productora;

public interface ProductoraDAO {
    ArrayList<Productora> listarTodas();
}
