package pe.edu.pucp.eventmastersoft.model;
public enum TipoEvento {
    OBRA_TEATRAL, CONCIERTO
}
