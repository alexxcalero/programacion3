﻿using EventMasterSoftModel;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventMasterSoft
{
    /* Ingrese sus datos:
         * Codigo PUCP:
         * Nombre Completo:
    * */
    public class Program
    {
        /* Descomente la siguiente linea de codigo */
        //private static ProductoraDAO daoProductora;
        private static Productora productora;
        public static void Main(string[] args)
        {
            int opcion = 0;
            do
            {
                Console.WriteLine("SISTEMA DE GESTION DE PRODUCTORAS");
                Console.WriteLine("------------------------------------------");
                Console.WriteLine("1. Registrar nueva productora.");
                Console.WriteLine("2. Listar todas las productoras.");
                Console.WriteLine("3. Obtener los datos de una productora.");
                Console.WriteLine("4. Eliminar una productora.");
                Console.WriteLine("5. Modificar una productora.");
                Console.WriteLine("6. Salir del sistema de gestión");
                Console.Write("Ingrese su opcion: ");
                opcion = Int32.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        productora = solicitarDatosRegistro();
                        //Completar las instrucciones
                        break;
                    case 2:
                        //Completar las instrucciones
                        break;
                    case 3:
                        //Completar las instrucciones
                        break;
                    case 4:
                        //Completar las instrucciones
                        break;
                    case 5:
                        System.Console.Write("Ingrese el id de la productora cuyos datos desea modificar: ");
                        //productora = solicitarDatosModificar(Int32.Parse(System.Console.ReadLine()));
                        //Completar las instrucciones
                        break;
                    case 6:
                        break;
                    default:
                        Console.WriteLine("Ingrese una opcion valida.");
                        break;
                }
            } while (opcion != 6);
        }

        public static Productora solicitarDatosRegistro()
        {
            Productora productora = new Productora();
            //Complete el código
            return productora;
        }

        /* Descomentar y completar el código */
        /*
        public static Productora solicitarDatosModificar(int idProductora)
        {
            System.Console.WriteLine("Si desea mantener el valor actual de algun campo, simplemente presione ENTER:");
            Productora productora = daoProductora.obtenerPorId(idProductora);
            //Completar código
            return productora;
        }
        */
    }
}
